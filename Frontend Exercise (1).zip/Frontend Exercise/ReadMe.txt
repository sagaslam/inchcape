Task 1: Create a responsive web page for mock(Details-Screen.jpg) layout using the HTML and CSS.
       logo: images/inchcapelogo.jpg
       Vehicle image: images/audi-a1.jpg
 

Task 2: On click of "Enquire Now" button send information(First name,Last name,Email,Phone number, Postcode) to API endpoint (http://localhost:9001/submitEnquiry).

Please place the code files inside src folder.
 